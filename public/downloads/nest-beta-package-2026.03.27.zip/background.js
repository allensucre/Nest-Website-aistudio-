/**
 * Nest - Background Service Worker
 */

const GEMINI_API_URL =
    'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent';

const providerNextAllowedAt = new Map();
let archiveInFlight = false;
const MENU_IDS = {
    archiveAllTabs: 'smart-context-archive-all-tabs',
    quickPinCurrentPage: 'smart-context-quick-pin-current-page',
    openArchives: 'smart-context-open-archives',
};

// ─── PostHog Analytics Client ─────────────────────────────────
const trackPostHogEvent = async (eventName, properties = {}) => {
    try {
        let distinctId;
        const result = await chrome.storage.local.get(["ph_distinct_id"]);
        if (result.ph_distinct_id) {
            distinctId = result.ph_distinct_id;
        } else {
            distinctId = crypto.randomUUID();
            await chrome.storage.local.set({ ph_distinct_id: distinctId });
        }
        fetch("https://us.i.posthog.com/capture/", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                api_key: "phc_hMXKeLo5exCEOsfxMyW3jZ2pIYzUuIcrOevvOFknxgq",
                event: eventName,
                properties: { distinct_id: distinctId, $lib: "chrome_extension_bg", ...properties },
                timestamp: new Date().toISOString()
            })
        }).catch(() => { });
    } catch (e) { }
};

// ─── Main Logic ───────────────────────────────────────────────

function createContextMenus() {
    chrome.contextMenus.removeAll(() => {
        chrome.contextMenus.create({
            id: MENU_IDS.archiveAllTabs,
            title: 'Save Tabs as Snapshot',
            contexts: ['action', 'page']
        });
        chrome.contextMenus.create({
            id: MENU_IDS.quickPinCurrentPage,
            title: 'Save Current Page',
            contexts: ['action', 'page']
        });
        chrome.contextMenus.create({
            id: MENU_IDS.openArchives,
            title: 'Open Saved Cards',
            contexts: ['action', 'page']
        });
    });
}

chrome.runtime.onInstalled.addListener(() => {
    createContextMenus();
});

chrome.runtime.onStartup.addListener(() => {
    createContextMenus();
});

chrome.action.onClicked.addListener(async () => {
    try {
        await archiveCurrentWindow();
    } catch (err) {
        console.error('[SmartContext] Background error:', err);
        chrome.tabs.create({ url: chrome.runtime.getURL('index.html') });
    }
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
    try {
        if (info.menuItemId === MENU_IDS.archiveAllTabs) {
            await archiveCurrentWindow();
            return;
        }

        if (info.menuItemId === MENU_IDS.quickPinCurrentPage) {
            const url = info.pageUrl || tab?.url;
            if (!url) return;
            await handleQuickPin(url, tab?.title || url, tab?.favIconUrl || '');
            return;
        }

        if (info.menuItemId === MENU_IDS.openArchives) {
            await openOrFocusArchive(chrome.runtime.getURL('index.html'));
        }
    } catch (err) {
        console.error('[SmartContext] Context menu action failed:', err);
    }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'regenerate_summary') {
        handleRegenerateSummary(request.links, request.rawContents)
            .then(data => sendResponse({ success: true, data }))
            .catch(err => sendResponse({ success: false, error: err.message }));
        return true;
    }
    if (request.action === 'refresh_single_link') {
        handleRefreshSingleLink(request.link)
            .then(data => sendResponse({ success: true, data }))
            .catch(err => sendResponse({ success: false, error: err.message }));
        return true;
    }
    if (request.action === 'chat_with_context') {
        handleChatWithContext(request.links, request.rawContents, request.history)
            .then(data => sendResponse({ success: true, data }))
            .catch(err => sendResponse({ success: false, error: err.message }));
        return true;
    }
    if (request.action === 'quick_pin') {
        handleQuickPin(request.url, request.title, request.favicon)
            .then(data => sendResponse({ success: true, data }))
            .catch(err => sendResponse({ success: false, error: err.message }));
        return true;
    }
    if (request.action === 'archive_all_tabs') {
        archiveCurrentWindow()
            .then((data) => sendResponse({ success: true, data }))
            .catch(err => sendResponse({ success: false, error: err.message }));
        return true;
    }
});

async function getAIConfig() {
    const stored = await chrome.storage.local.get([
        'ai_provider',
        'ai_api_key',
        'gemini_api_key',
        'custom_base_url',
        'custom_model'
    ]);

    const provider = (stored.ai_provider || 'qwen').trim();
    const sharedKey = typeof stored.ai_api_key === 'string' ? stored.ai_api_key.trim() : '';
    const legacyGeminiKey = typeof stored.gemini_api_key === 'string' ? stored.gemini_api_key.trim() : '';
    const customBaseUrl = typeof stored.custom_base_url === 'string'
        ? stored.custom_base_url.trim()
        : '';
    const customModel = typeof stored.custom_model === 'string'
        ? stored.custom_model.trim()
        : '';

    // Preserve backward compatibility for old Gemini-only installs.
    const apiKey = provider === 'gemini'
        ? (sharedKey || legacyGeminiKey)
        : sharedKey;

    return { provider, apiKey, customBaseUrl, customModel };
}

function getProviderMeta(provider, customBaseUrl, customModel) {
    switch (provider) {
        case 'gemini':
            return {
                endpoint: GEMINI_API_URL,
                modelName: "gemini-2.0-flash",
                protocol: 'gemini'
            };
        case 'glm':
            return {
                endpoint: "https://open.bigmodel.cn/api/paas/v4/chat/completions",
                modelName: "glm-4-flash",
                protocol: 'openai'
            };
        case 'openai':
            return {
                endpoint: customBaseUrl || "https://api.openai.com/v1/chat/completions",
                modelName: customModel || "gpt-4.1-mini",
                protocol: 'openai'
            };
        case 'xai':
            return {
                endpoint: customBaseUrl || "https://api.x.ai/v1/chat/completions",
                modelName: customModel || "grok-3-mini-beta",
                protocol: 'openai'
            };
        case 'groq':
            return {
                endpoint: customBaseUrl || "https://api.groq.com/openai/v1/chat/completions",
                modelName: customModel || "llama-3.3-70b-versatile",
                protocol: 'openai'
            };
        case 'together':
            return {
                endpoint: customBaseUrl || "https://api.together.xyz/v1/chat/completions",
                modelName: customModel || "meta-llama/Llama-3.3-70B-Instruct-Turbo",
                protocol: 'openai'
            };
        case 'siliconflow':
            return {
                endpoint: customBaseUrl || "https://api.siliconflow.cn/v1/chat/completions",
                modelName: customModel || "Qwen/Qwen2.5-72B-Instruct",
                protocol: 'openai'
            };
        case 'fireworks':
            return {
                endpoint: customBaseUrl || "https://api.fireworks.ai/inference/v1/chat/completions",
                modelName: customModel || "accounts/fireworks/models/llama4-maverick-instruct-basic",
                protocol: 'openai'
            };
        case 'deepseek':
            return {
                endpoint: "https://api.deepseek.com/chat/completions",
                modelName: "deepseek-chat",
                protocol: 'openai'
            };
        case 'kimi':
            return {
                endpoint: "https://api.moonshot.cn/v1/chat/completions",
                modelName: "moonshot-v1-8k",
                protocol: 'openai'
            };
        case 'minimax':
            return {
                endpoint: "https://api.minimax.chat/v1/text/chatcompletion_v2",
                modelName: "abab6.5s-chat",
                protocol: 'openai'
            };
        case 'openrouter':
            return {
                endpoint: customBaseUrl || "https://openrouter.ai/api/v1",
                modelName: customModel || "google/gemini-2.0-flash-exp:free",
                protocol: 'openai'
            };
        case 'qwen':
            return {
                endpoint: customBaseUrl || "https://openrouter.ai/api/v1",
                modelName: customModel || "qwen/qwen3-235b-a22b:free",
                protocol: 'openai'
            };
        case 'custom':
            return {
                endpoint: customBaseUrl || "",
                modelName: customModel || "",
                protocol: 'openai'
            };
        default:
            throw new Error(`Unknown provider: ${provider}`);
    }
}

function normalizeOpenAICompatibleUrl(provider, endpoint) {
    if (
        provider !== 'custom' &&
        provider !== 'openrouter' &&
        provider !== 'qwen' &&
        provider !== 'openai' &&
        provider !== 'xai' &&
        provider !== 'groq' &&
        provider !== 'together' &&
        provider !== 'siliconflow' &&
        provider !== 'fireworks'
    ) {
        return endpoint;
    }
    if (!endpoint) return endpoint;
    return endpoint.includes('/chat/completions')
        ? endpoint
        : endpoint.replace(/\/+$/, '') + '/chat/completions';
}

function buildAuthHeaders(provider, apiKey, normalizedUrl) {
    const headers = { 'Content-Type': 'application/json' };

    if (provider === 'gemini') {
        return headers;
    }

    headers['Authorization'] = `Bearer ${apiKey}`;

    // GLM's OpenAI-compatible endpoint expects bearer auth; keep a secondary
    // header for better compatibility with upstream gateway changes.
    if (provider === 'glm') {
        headers['X-API-Key'] = apiKey;
    }

    if (provider === 'openrouter' || normalizedUrl.includes('openrouter.ai')) {
        headers['HTTP-Referer'] = 'https://github.com/allensucre/Smart-Context-Archiving-Center';
        headers['X-Title'] = 'Nest';
    }

    return headers;
}

function buildAuthErrorMessage(provider, errText) {
    const raw = typeof errText === 'string' ? errText : '';
    if (provider === 'glm') {
        return "⚠️ GLM 鉴权失败 (401)：智谱免费模型仍然需要在设置页填写 BigModel API Key。请确认当前 Provider 选的是 GLM，且 Key 来自 bigmodel.cn，而不是 Gemini/OpenRouter 的 Key。";
    }
    if (provider === 'gemini') {
        return "⚠️ Gemini 鉴权失败 (401)：请检查 API Key 是否有效，且以 AIza 开头。";
    }
    if (provider === 'openrouter' || provider === 'qwen') {
        return "⚠️ OpenRouter 鉴权失败 (401)：请检查 OpenRouter API Key 和 Base URL。";
    }
    return `HTTP 401: ${raw.slice(0, 150)}`;
}

function isRateLimitError(statusOrCode, rawText = '') {
    const normalized = String(statusOrCode || '').trim();
    return normalized === '429' || normalized === '1302' || /速率限制|rate limit|too many requests/i.test(rawText);
}

function buildRateLimitMessage(provider) {
    if (provider === 'glm') {
        return "⚠️ API 频率超限：GLM 返回限流。免费额度对连续请求较敏感，请等待 10-20 秒后重试，避免连续点击 Regenerate 或立刻重复发起 Chat。";
    }
    if (provider === 'openrouter' || provider === 'qwen') {
        return "⚠️ API 频率超限 (429)：账户请求频率过快。OpenRouter 免费模型限制极其严格（通常每分钟仅允许极少量请求）。建议稍等一分钟后再试，或者切换到 OpenRouter 里的 google/gemini-2.0-flash-exp:free。";
    }
    return "⚠️ API 频率超限：账户请求过快，请稍等后重试。";
}

async function waitForProviderSlot(provider) {
    const minIntervals = {
        glm: 6000,
        openrouter: 8000,
        qwen: 8000,
        gemini: 1500,
        deepseek: 1500,
        kimi: 1500,
        minimax: 1500,
        custom: 1500
    };
    const now = Date.now();
    const nextAllowedAt = providerNextAllowedAt.get(provider) || 0;
    if (nextAllowedAt > now) {
        await sleep(nextAllowedAt - now);
    }
    providerNextAllowedAt.set(provider, Date.now() + (minIntervals[provider] || 1500));
}

function pushBackProviderSlot(provider, ms) {
    const current = providerNextAllowedAt.get(provider) || 0;
    providerNextAllowedAt.set(provider, Math.max(current, Date.now() + ms));
}

function buildBalancedRawContext(tabs, rawContents, maxChars, maxPages = 8) {
    const rawByUrl = new Map((rawContents || []).map(item => [item.url, item.content || '']));
    const ordered = (tabs || [])
        .map(tab => ({
            url: tab.url,
            title: tab.title || 'Untitled',
            content: (rawByUrl.get(tab.url) || '').replace(/\s+/g, ' ').trim()
        }))
        .filter(item => item.url && item.content);

    if (ordered.length === 0) {
        return "";
    }

    const selected = ordered.slice(0, maxPages);
    const reservedForHeaders = selected.reduce((sum, item) => {
        return sum + (`=== Page: ${item.title} | ${item.url} ===\n\n`).length;
    }, 0);
    const availableChars = Math.max(2000, maxChars - reservedForHeaders);
    const perPageBudget = Math.max(400, Math.floor(availableChars / selected.length));

    return selected.map(item => {
        const excerpt = item.content.slice(0, perPageBudget);
        return `=== Page: ${item.title} | ${item.url} ===\n${excerpt}`;
    }).join('\n\n');
}

function buildLongSummaryMarkdown(coreInsight, keyPoints, followUpQuestions) {
    const sections = [];
    if (coreInsight) {
        sections.push(`## 核心洞察\n${coreInsight}`);
    }
    if (Array.isArray(keyPoints) && keyPoints.length > 0) {
        sections.push(`## 关键要点\n${keyPoints.map(item => `- ${item}`).join('\n')}`);
    }
    if (Array.isArray(followUpQuestions) && followUpQuestions.length > 0) {
        sections.push(`## 猜你想了解\n${followUpQuestions.map(item => `- [ ] ${item}`).join('\n')}`);
    }
    return sections.join('\n\n').trim();
}

function normalizeSummaryPayload(payload) {
    const coreInsight = typeof payload?.core_insight === 'string'
        ? payload.core_insight.trim()
        : typeof payload?.coreInsight === 'string'
            ? payload.coreInsight.trim()
            : '';
    const keyPoints = Array.isArray(payload?.key_points)
        ? payload.key_points.map(item => String(item).trim()).filter(Boolean)
        : Array.isArray(payload?.keyPoints)
            ? payload.keyPoints.map(item => String(item).trim()).filter(Boolean)
            : [];
    const followUpQuestions = Array.isArray(payload?.follow_up_questions)
        ? payload.follow_up_questions.map(item => String(item).trim()).filter(Boolean)
        : Array.isArray(payload?.followUpQuestions)
            ? payload.followUpQuestions.map(item => String(item).trim()).filter(Boolean)
            : [];
    const summaryCoverage = typeof payload?.summary_coverage === 'string'
        ? payload.summary_coverage.trim()
        : typeof payload?.summaryCoverage === 'string'
            ? payload.summaryCoverage.trim()
            : '';
    const longSummary = typeof payload?.long_summary === 'string'
        ? payload.long_summary.trim()
        : typeof payload?.longSummary === 'string'
            ? payload.longSummary.trim()
            : '';

    return {
        ...payload,
        coreInsight,
        keyPoints,
        followUpQuestions,
        summaryCoverage,
        long_summary: longSummary || buildLongSummaryMarkdown(coreInsight, keyPoints, followUpQuestions),
    };
}

function summarizeTitles(links, maxItems = 3) {
    return links
        .slice(0, maxItems)
        .map(link => link.title || link.url || 'Untitled')
        .filter(Boolean)
        .join(' / ');
}

const TITLE_STOPWORDS = new Set([
    'the', 'and', 'for', 'with', 'from', 'that', 'this', 'into', 'about', 'your', 'their',
    'what', 'when', 'where', 'how', 'why', 'will', 'have', 'has', '2024', '2025', '2026',
    'design', 'guide', 'using', 'used', 'more', 'than', 'over', 'under', 'best', 'tips',
    'page', 'pages', 'article', 'medium', 'official', 'introduction', 'overview',
    '一个', '关于', '如何', '什么', '以及', '进行', '设计', '趋势', '指南', '总结', '页面', '文章'
]);

const AUTO_TAG_TAXONOMY = {
    Design: ['design', 'ui', 'ux', 'prototype', 'figma', 'visual', 'interface', 'layout', 'brand'],
    Research: ['research', 'trend', 'analysis', 'study', 'market', 'benchmark', 'insight'],
    Docs: ['docs', 'documentation', 'guide', 'reference', 'api', 'manual', 'spec'],
    Debug: ['bug', 'debug', 'fix', 'issue', 'error', 'crash', 'troubleshoot'],
    Product: ['product', 'strategy', 'roadmap', 'feature', 'growth', 'pmf', 'user'],
    Engineering: ['engineering', 'frontend', 'backend', 'react', 'typescript', 'javascript', 'chrome', 'extension', 'android', 'ios']
};

function tokenizeTitle(text) {
    return String(text || '')
        .toLowerCase()
        .replace(/https?:\/\/\S+/g, ' ')
        .replace(/[^a-z0-9\u4e00-\u9fff\s-]/g, ' ')
        .split(/\s+/)
        .map(token => token.trim())
        .filter(token => token.length >= 2 && !TITLE_STOPWORDS.has(token));
}

function extractTopKeywords(links, maxItems = 4) {
    const scores = new Map();
    for (const link of links) {
        const seen = new Set();
        for (const token of tokenizeTitle(link.title || link.url)) {
            if (seen.has(token)) continue;
            seen.add(token);
            scores.set(token, (scores.get(token) || 0) + 1);
        }
    }

    return [...scores.entries()]
        .sort((a, b) => {
            if (b[1] !== a[1]) return b[1] - a[1];
            return a[0].length - b[0].length;
        })
        .slice(0, maxItems)
        .map(([token]) => token);
}

function summarizeDomains(links, maxItems = 3) {
    const uniqueDomains = [];
    for (const link of links) {
        try {
            const domain = new URL(link.url).hostname.replace(/^www\./, '');
            if (domain && !uniqueDomains.includes(domain)) {
                uniqueDomains.push(domain);
            }
        } catch { }
        if (uniqueDomains.length >= maxItems) break;
    }
    return uniqueDomains.join(', ');
}

function countUniqueDomains(links) {
    const set = new Set();
    for (const link of links) {
        try {
            set.add(new URL(link.url).hostname.replace(/^www\./, ''));
        } catch { }
    }
    return set.size;
}

function inferArchiveMode(links) {
    const domainCount = countUniqueDomains(links);
    if (domainCount <= 1) return '单一来源资料';
    if (domainCount <= 3) return '多来源专题资料';
    return '跨站点研究资料';
}

function normalizeTagLabel(name) {
    return String(name || '')
        .toLowerCase()
        .replace(/[^a-z0-9\u4e00-\u9fff]+/g, ' ')
        .trim();
}

function inferAutoTagLabels(links) {
    const bag = links.flatMap(link => [
        ...tokenizeTitle(link.title || ''),
        ...tokenizeTitle(link.url || '')
    ]);

    const matched = [];
    for (const [label, keywords] of Object.entries(AUTO_TAG_TAXONOMY)) {
        const score = keywords.reduce((sum, keyword) => sum + (bag.includes(keyword) ? 1 : 0), 0);
        if (score > 0) matched.push({ label, score });
    }

    return matched
        .sort((a, b) => b.score - a.score)
        .slice(0, 2)
        .map(item => item.label);
}

function resolveAutoTags(userTags, inferredLabels) {
    const autoTagIds = [];

    for (const label of inferredLabels) {
        const normalizedLabel = normalizeTagLabel(label);
        const aliasSet = new Set([
            normalizedLabel,
            ...AUTO_TAG_TAXONOMY[label].map(normalizeTagLabel)
        ]);

        const existing = userTags.find(tag => {
            const normalizedName = normalizeTagLabel(tag.name);
            if (aliasSet.has(normalizedName)) return true;
            return [...aliasSet].some(alias => normalizedName.includes(alias) || alias.includes(normalizedName));
        });

        if (existing) {
            if (!autoTagIds.includes(existing.id)) autoTagIds.push(existing.id);
        }
    }

    return { autoTagIds };
}

function buildArchivePlaceholder(links) {
    const count = links.length;
    const topKeywords = extractTopKeywords(links);
    const domainDigest = summarizeDomains(links);
    const archiveMode = inferArchiveMode(links);
    const topicLine = topKeywords.length > 0
        ? `主题焦点：${topKeywords.join(' / ')}`
        : summarizeTitles(links, 2)
            ? `主题线索：${summarizeTitles(links, 2)}`
            : '已保存当前窗口的浏览上下文。';

    return [
        `${archiveMode}，共收纳 ${count} 个标签页${domainDigest ? `，覆盖 ${domainDigest}` : ''}。`,
        topicLine,
        '需要深入分析时，再使用 Generate from Links 生成 Snapshot。'
    ];
}

function buildQuickPinPlaceholder(link) {
    let domain = '';
    try {
        domain = new URL(link.url).hostname.replace(/^www\./, '');
    } catch { }
    const keywords = extractTopKeywords([link], 3);
    return [
        `已保存当前页面${domain ? `，来源于 ${domain}` : ''}。`,
        keywords.length > 0 ? `主题焦点：${keywords.join(' / ')}` : `页面标题：${link.title || link.url}`,
        '需要深入分析时，再使用 Generate from Links 生成 Snapshot。'
    ];
}

async function handleRegenerateSummary(links, rawContents) {
    const { provider, apiKey, customBaseUrl, customModel } = await getAIConfig();

    if (!apiKey) throw new Error("AI_SETTINGS_REQUIRED: AI 未配置。请先在 AI Settings 中填写 API Key。");

    let effectiveRawContents = rawContents || [];
    if (effectiveRawContents.length === 0 && links.length > 0) {
        effectiveRawContents = await fetchAndScrapeLinks(links);
    }

    return await callAIProvider(provider, apiKey, links, effectiveRawContents, customBaseUrl, customModel);
}

async function handleRefreshSingleLink(link) {
    const MAX_CHARS_PER_PAGE = 8000;
    try {
        const response = await fetch(link.url, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml'
            },
            redirect: 'follow'
        });
        if (!response.ok) throw new Error('Failed to fetch URL');
        const html = await response.text();

        let title = link.title;
        const titleMatch = html.match(/<title[^>]*>([^<]+)<\/title>/i);
        if (titleMatch && titleMatch[1]) {
            title = titleMatch[1].trim().replace(/&amp;/g, '&').replace(/&#39;/g, "'").replace(/&quot;/g, '"');
        }

        let favicon = link.favicon;
        const faviconMatch = html.match(/<link[^>]+rel=["']?(?:shortcut )?icon["']?[^>]+href=["']?([^"'>]+)["']?/i);
        if (faviconMatch && faviconMatch[1]) {
            let iconUrl = faviconMatch[1];
            if (iconUrl.startsWith('//')) iconUrl = 'https:' + iconUrl;
            else if (iconUrl.startsWith('/')) iconUrl = new URL(link.url).origin + iconUrl;
            else if (!iconUrl.startsWith('http')) iconUrl = new URL(link.url).origin + '/' + iconUrl;
            favicon = iconUrl;
        }

        let text = html
            .replace(/<script[\s\S]*?<\/script>/gi, '')
            .replace(/<style[\s\S]*?<\/style>/gi, '')
            .replace(/<[^>]+>/g, ' ')
            .replace(/&nbsp;/g, ' ')
            .replace(/[\t ]{2,}/g, ' ')
            .replace(/\n{3,}/g, '\n\n')
            .trim();

        return {
            updatedLink: { ...link, title, favicon },
            content: { url: link.url, content: text.slice(0, MAX_CHARS_PER_PAGE) }
        };
    } catch (e) {
        console.warn(`[SmartContext] Refresh failed:`, e.message);
        throw e;
    }
}

async function handleChatWithContext(links, rawContents, history) {
    const { provider, apiKey, customBaseUrl, customModel } = await getAIConfig();

    if (!apiKey) throw new Error("AI_SETTINGS_REQUIRED: AI 未配置。请先在 AI Settings 中填写 API Key。");

    let effectiveRawContents = rawContents || [];
    if (effectiveRawContents.length === 0 && links && links.length > 0) {
        effectiveRawContents = await fetchAndScrapeLinks(links);
    }

    const rawTextBlock = effectiveRawContents && effectiveRawContents.length > 0
        ? buildBalancedRawContext(links, effectiveRawContents, 16000, 6)
        : null;

    const tabList = links.slice(0, 20).map((t, i) => (i + 1) + '. [' + t.title + '](' + t.url + ')').join('\n');
    const userLocale = chrome.i18n.getUILanguage() || 'en-US';

    const systemPrompt = `You are a research assistant. Analyze the provided pages to answer.
<reference_texts>
${tabList}
${rawTextBlock || '(No full page text available)'}
</reference_texts>
Respond in ${userLocale.startsWith('zh') ? 'Chinese' : 'English'}.`;

    return await callAIProvider(provider, apiKey, links, effectiveRawContents, customBaseUrl, customModel, history, systemPrompt);
}

async function callAIProvider(provider, apiKey, tabs, rawContents, customBaseUrl, customModel, history = null, chatSystemPrompt = null) {
    let retryCount = 0;
    const MAX_RETRIES = 3;

    while (retryCount <= MAX_RETRIES) {
        try {
            const { endpoint, modelName, protocol } = getProviderMeta(provider, customBaseUrl, customModel);
            await waitForProviderSlot(provider);

            const userLocale = chrome.i18n.getUILanguage() || 'en-US';
            const isFreeModel = (modelName && modelName.includes(':free')) || provider === 'openrouter';
            // Further reduce chars for free models to avoid token limits per minute (TPM)
            const MAX_CHARS = isFreeModel ? 10000 : 40000;

            const combinedRaw = buildBalancedRawContext(tabs, rawContents, MAX_CHARS, isFreeModel ? 6 : 8);

            // Define prompts if it's NOT a chat call (Summary flow)
            let systemPrompt = chatSystemPrompt;
            let userPrompt = history ? history[history.length - 1].content : "";

            if (!history) {
                // Summary Generation Logic
                const tabList = tabs.slice(0, 20).map((t, i) => `${i + 1}. [${t.title}](${t.url})`).join('\n');
                systemPrompt = `You are a Top-tier Strategic Information Analyst. Apply "Cognitive Compression" strictly.
DO NOT use empathy, role-playing, or first-person narrative. Provide extreme factual density, logic, and compression.
You are summarizing a multi-link archive, not a single article.
Coverage rules:
1. Inspect all provided pages/excerpts before concluding the main topic.
2. If the pages cover multiple subtopics, summarize the shared theme first, then explicitly note the major subtopics or divergences.
3. Do NOT overfit to the first link. Do NOT write a summary that could describe only one page if multiple pages are provided.
4. In long_summary, cite source titles or URLs when comparing different pages.

Return ONLY a valid JSON object strictly matching this schema.
{
  "title": "Precise verb-noun title (Max 6 words)",
  "tag": "Auto-categorize (e.g. Dev / Research / Design / Tool...)",
  "type": "One of: task | asset | archive",
  "summary": [
    "Fact Description: 1 sentence summarizing the shared theme across the archive. If the pages are mixed, say that explicitly.",
    "Core Increment: Extract the most valuable comparison, contrast, or grouped insight across multiple links.",
    "Progress Anchor: State what the user should inspect next based on the archive as a whole, not a single page."
  ],
  "summary_coverage": "One short sentence stating the coverage scope, e.g. 综合当前 6 个链接",
  "core_insight": "One precise sentence defining the working context or core conclusion",
  "key_points": [
    "A concise but concrete key point grounded in the archive",
    "Another key point or comparison grounded in the archive"
  ],
  "follow_up_questions": [
    "A concrete follow-up question worth asking next",
    "Another concrete follow-up question"
  ],
  "long_summary": "Optional markdown mirror of the structured fields. Keep it concise and aligned with the structured output."
}

CRITICAL LANGUAGE REQUIREMENT:
You MUST generate the entire JSON output (including title, summary, summary_coverage, core_insight, key_points, follow_up_questions, long_summary) entirely in the language corresponding to this locale: [${userLocale}]. Never use English to reply unless the locale is en-US or similar.`;
                userPrompt = `Tabs:\n${tabList}\n\nArchive content excerpts from multiple links:\n${combinedRaw}`;
            }

            let finalResponse;
            if (protocol === 'gemini') {
                const contents = history 
                    ? history.map(m => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] }))
                    : [{ role: 'user', parts: [{ text: systemPrompt + "\n\n" + userPrompt }] }];
                
                if (history && systemPrompt) contents[0].parts[0].text = systemPrompt + "\n\n" + contents[0].parts[0].text;

                finalResponse = await fetch(`${endpoint}${endpoint.includes('?')?'&':'?'}key=${apiKey}`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ contents, generationConfig: { temperature: 0.4, maxOutputTokens: 4000 } })
                });
            } else {
                const normalizedUrl = normalizeOpenAICompatibleUrl(provider, endpoint);
                const headers = buildAuthHeaders(provider, apiKey, normalizedUrl);

                const messages = history ? history : [ { role: "system", content: systemPrompt }, { role: "user", content: userPrompt } ];

                finalResponse = await fetch(normalizedUrl, {
                    method: 'POST',
                    headers: headers,
                    body: JSON.stringify({ model: modelName, messages, temperature: 0.4, max_tokens: 4000 })
                });
            }

            if (!finalResponse.ok) {
                const err = await finalResponse.text();
                // Specifically catch 429 for retries
                if (finalResponse.status === 429 && retryCount < MAX_RETRIES) {
                    retryCount++;
                    // OpenRouter free models have strict RPM. Increase backoff.
                    const backoffBase = provider === 'openrouter' ? 8000 : 2000;
                    const delay = backoffBase * Math.pow(2, retryCount - 1) + Math.random() * 2000;
                    pushBackProviderSlot(provider, delay);
                    console.warn(`[SmartContext] AI 429 Rate Limit. Retrying ${retryCount}/${MAX_RETRIES} in ${Math.round(delay / 1000)}s...`);
                    await sleep(delay);
                    continue;
                }
                
                let msg = `HTTP ${finalResponse.status}: ${err.slice(0, 150)}`;
                if (isRateLimitError(finalResponse.status, err)) {
                    msg = buildRateLimitMessage(provider);
                } else if (finalResponse.status === 402) {
                    msg = "⚠️ 余额不足 (402)：请检查 OpenRouter 账户余额。";
                } else if (finalResponse.status === 401) {
                    msg = buildAuthErrorMessage(provider, err);
                }
                throw new Error(`${msg}\n\nRaw Error: ${err.slice(0, 100)}`);
            }

            const data = await finalResponse.json();

            // OpenRouter may return HTTP 200 with an error object; handle it explicitly.
            if (data && data.error) {
                const errCode = data.error.code;
                const errMsg = typeof data.error.message === 'string' ? data.error.message : 'Provider returned error';
                const errRaw = data.error.metadata && data.error.metadata.raw ? String(data.error.metadata.raw) : '';

                if (isRateLimitError(errCode, `${errMsg} ${errRaw}`) && retryCount < MAX_RETRIES) {
                    retryCount++;
                    const backoffBase = provider === 'openrouter' ? 8000 : 2000;
                    const delay = backoffBase * Math.pow(2, retryCount - 1) + Math.random() * 2000;
                    pushBackProviderSlot(provider, delay);
                    console.warn(`[SmartContext] AI 429 Rate Limit (body). Retrying ${retryCount}/${MAX_RETRIES} in ${Math.round(delay / 1000)}s...`);
                    await sleep(delay);
                    continue;
                }

                let msg = `HTTP ${errCode || 'error'}: ${errMsg}`;
                if (isRateLimitError(errCode, `${errMsg} ${errRaw}`)) {
                    msg = buildRateLimitMessage(provider);
                } else if (errCode === 402) {
                    msg = "⚠️ 余额不足 (402)：请检查 OpenRouter 账户余额。";
                }
                throw new Error(`${msg}\n\nRaw Error: ${errRaw.slice(0, 100)}`);
            }

            const raw = protocol === 'gemini' ? data?.candidates?.[0]?.content?.parts?.[0]?.text : data?.choices?.[0]?.message?.content;
            
            if (!history) return parseAIResponse(raw || "");
            return raw || "";

        } catch (err) {
            if (retryCount >= MAX_RETRIES) throw err;
            retryCount++;
            await sleep(1000 * retryCount);
        }
    }
}

function parseAIResponse(rawText) {
    try {
        let text = rawText.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '').trim();
        const start = text.indexOf('{');
        if (start === -1) throw new Error("Invalid JSON structure");
        text = text.slice(start);
        try { return normalizeSummaryPayload(JSON.parse(text)); } catch { }
        const extracted = extractFirstJsonObject(text);
        if (!extracted) throw new Error("Invalid JSON structure");
        return normalizeSummaryPayload(JSON.parse(extracted));
    } catch (e) { throw new Error("AI 响应解析失败: " + e.message); }
}

function extractFirstJsonObject(text) {
    let depth = 0;
    let inString = false;
    let escaped = false;
    for (let i = 0; i < text.length; i++) {
        const ch = text[i];
        if (inString) {
            if (escaped) {
                escaped = false;
            } else if (ch === '\\\\') {
                escaped = true;
            } else if (ch === '"') {
                inString = false;
            }
            continue;
        }
        if (ch === '"') { inString = true; continue; }
        if (ch === '{') depth++;
        if (ch === '}') {
            depth--;
            if (depth === 0) return text.slice(0, i + 1);
        }
    }
    return null;
}

async function scrapeTabContents(tabs, options = {}) {
    const MAX = 8000;
    const { perTabTimeoutMs = 1200, onlyComplete = false } = options;
    const candidates = onlyComplete ? tabs.filter(tab => tab.status === 'complete') : tabs;
    const promises = candidates.map(async (tab) => {
        if (!tab.id || !tab.url || tab.url.startsWith('chrome')) return null;
        try {
            const results = await Promise.race([
                chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    func: () => document.body.innerText.slice(0, 10000)
                }),
                sleep(perTabTimeoutMs).then(() => null)
            ]);
            const text = results?.[0]?.result || '';
            return text.length > 20 ? { url: tab.url, content: text.slice(0, MAX) } : null;
        } catch { return null; }
    });
    return (await Promise.all(promises)).filter(Boolean);
}

async function fetchAndScrapeLinks(links) {
    const MAX = 8000;
    const results = [];
    for (const link of links.slice(0, 10)) {
        try {
            const res = await fetch(link.url);
            if (!res.ok) continue;
            const html = await res.text();
            const text = html.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
            if (text.length > 20) results.push({ url: link.url, content: text.slice(0, MAX) });
        } catch { }
    }
    return results;
}

const sleep = (ms) => new Promise(res => setTimeout(res, ms));

async function archiveCurrentWindow() {
    if (archiveInFlight) {
        return { savedTabCount: 0, firstSnapshot: false };
    }
    archiveInFlight = true;

    const archivePageFullUrl = chrome.runtime.getURL('index.html');
    try {
        const allTabs = await chrome.tabs.query({ currentWindow: true });
        const archivable = allTabs.filter(t => t.url && !t.url.startsWith(archivePageFullUrl) && !t.url.startsWith('chrome'));
        
        if (archivable.length === 0) {
            await openOrFocusArchive(archivePageFullUrl);
            return { savedTabCount: 0, firstSnapshot: false };
        }

        const links = archivable.map((t, i) => ({ id: `tab-${Date.now()}-${i}`, title: t.title || 'Untitled', url: t.url, favicon: t.favIconUrl || '' }));
        const { userTags = [] } = await chrome.storage.local.get(['userTags']);
        const inferredLabels = inferAutoTagLabels(links);
        const { autoTagIds } = resolveAutoTags(userTags, inferredLabels);
        const sessionId = `session-${Date.now()}`;
        const initialSession = {
            id: sessionId,
            title: generateAutoTitle(archivable),
            tag: 'Saved',
            type: 'archive',
            summary: buildArchivePlaceholder(links),
            summaryCoverage: `综合当前 ${links.length} 个链接`,
            coreInsight: '',
            keyPoints: [],
            followUpQuestions: [],
            autoTagIds,
            long_summary: '',
            links,
            createdAt: new Date().toISOString()
        };
        
        let { sessions = [] } = await chrome.storage.local.get(['sessions']);
        const firstSnapshot = sessions.length === 0;
        await chrome.storage.local.set({ sessions: [initialSession, ...sessions].slice(0, 50) });
        
        const archiveTabId = await openOrFocusArchive(archivePageFullUrl);
        await chrome.tabs.remove(archivable.map(t => t.id).filter(id => id && id !== archiveTabId)).catch(() => {});

        void (async () => {
            try {
                const rawContents = await fetchAndScrapeLinks(links.slice(0, 5));
                if (rawContents.length > 0) {
                    const { sessions: s1 = [] } = await chrome.storage.local.get(['sessions']);
                    const idx = s1.findIndex(s => s.id === sessionId);
                    if (idx !== -1) {
                        s1[idx].rawContents = rawContents;
                        await chrome.storage.local.set({ sessions: s1 });
                    }
                }
            } catch (e) {
                console.warn('[SmartContext] Background fetch cache skipped:', e);
            }
        })();
        return { savedTabCount: links.length, firstSnapshot };
    } catch (e) {
        throw e;
    } finally {
        archiveInFlight = false;
    }
}

async function openOrFocusArchive(url) {
    const [existing] = await chrome.tabs.query({ url, currentWindow: true });
    if (existing?.id) { await chrome.tabs.update(existing.id, { active: true }); return existing.id; }
    const t = await chrome.tabs.create({ url }); return t.id;
}

function generateAutoTitle(tabs) {
    return `Saved ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
}

async function handleQuickPin(url, title, favicon) {
    const link = { id: `pin-${Date.now()}`, title, url, favicon };
    const { userTags = [] } = await chrome.storage.local.get(['userTags']);
    const inferredLabels = inferAutoTagLabels([link]);
    const { autoTagIds } = resolveAutoTags(userTags, inferredLabels);
    const sessionId = `session-${Date.now()}`;
    const initialSession = {
        id: sessionId,
        title,
        tag: 'Quick Pin',
        type: 'asset',
        summary: buildQuickPinPlaceholder(link),
        summaryCoverage: '当前单页',
        coreInsight: '',
        keyPoints: [],
        followUpQuestions: [],
        autoTagIds,
        long_summary: '',
        links: [link],
        createdAt: new Date().toISOString()
    };
    let { sessions = [] } = await chrome.storage.local.get(['sessions']);
    await chrome.storage.local.set({ sessions: [initialSession, ...sessions].slice(0, 50) });
    return { sessionId };
}
