// popup.js — Nest popup script

document.addEventListener('DOMContentLoaded', async () => {
  const favicon     = document.getElementById('favicon');
  const pageTitle   = document.getElementById('pageTitle');
  const btnPin      = document.getElementById('btnQuickPin');
  const btnArchive  = document.getElementById('btnArchive');
  const btnOpen     = document.getElementById('btnOpen');
  const statusEl    = document.getElementById('status');
  let archiveInFlight = false;

  // ── Load current active tab info ────────────────────────────
  let activeTab = null;
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    activeTab = tab;
    if (tab) {
      pageTitle.textContent = tab.title || tab.url || 'Unknown page';
      if (tab.favIconUrl) {
        favicon.src = tab.favIconUrl;
        favicon.onerror = () => { favicon.src = ''; favicon.style.display = 'none'; };
      } else {
        favicon.style.display = 'none';
      }
    }
  } catch (e) {
    pageTitle.textContent = 'Error loading page info';
  }

  // ── Helper: show status ──────────────────────────────────────
  function showStatus(msg, type = 'success', autoClose = true) {
    statusEl.textContent = msg;
    statusEl.className = `status visible ${type}`;
    if (type !== 'error' && autoClose) {
      setTimeout(() => window.close(), 1800);
    }
  }

  function setLoading(btn, loading) {
    btnPin.disabled = loading;
    btnArchive.disabled = loading;
    if (loading) {
      btn.style.opacity = '0.6';
    } else {
      btn.style.opacity = '';
    }
  }

  // ── 📌 Save current page ────────────────────────────────────
  btnPin.addEventListener('click', async () => {
    if (!activeTab || !activeTab.url) {
      showStatus('⚠️ No active tab found', 'error');
      return;
    }

    setLoading(btnPin, true);
    statusEl.className = 'status visible';
    statusEl.textContent = '🔄 Saving page...';

    try {
      const response = await chrome.runtime.sendMessage({
        action: 'quick_pin',
        url: activeTab.url,
        title: activeTab.title || activeTab.url,
        favicon: activeTab.favIconUrl || ''
      });

      if (response && response.success) {
        showStatus('✅ Snapshot ready', 'success');
      } else {
        showStatus(`⚠️ ${response?.error || 'Failed to pin page'}`, 'error');
        setLoading(btnPin, false);
      }
    } catch (err) {
      showStatus(`⚠️ ${err.message}`, 'error');
      setLoading(btnPin, false);
    }
  });

  // ── 📦 Save current tabs ──────────────────────────────────────
  btnArchive.addEventListener('click', async () => {
    if (archiveInFlight) return;
    archiveInFlight = true;
    setLoading(btnArchive, true);
    statusEl.className = 'status visible';
    statusEl.textContent = '🔄 Saving tabs...';

    try {
      const response = await chrome.runtime.sendMessage({ action: 'archive_all_tabs' });
      if (response && response.success) {
        const savedCount = Number(response?.data?.savedTabCount) || 0;
        const firstSnapshot = Boolean(response?.data?.firstSnapshot);

        if (savedCount > 0) {
          showStatus(`Saved ${savedCount} tabs`, 'success', false);
          setTimeout(() => {
            showStatus('Snapshot ready', 'success', false);
          }, 900);
          if (firstSnapshot) {
            setTimeout(() => {
              showStatus('Nest created your first snapshot.', 'success');
            }, 1800);
          } else {
            setTimeout(() => window.close(), 1800);
          }
        } else {
          showStatus('Snapshot ready', 'success');
        }
      } else {
        showStatus(`⚠️ ${response?.error || 'Failed to save tabs'}`, 'error');
        archiveInFlight = false;
        setLoading(btnArchive, false);
      }
    } catch (err) {
      showStatus(`⚠️ ${err.message}`, 'error');
      archiveInFlight = false;
      setLoading(btnArchive, false);
    }
  });

  // ── Open saved cards ─────────────────────────────────────────
  btnOpen.addEventListener('click', async () => {
    const archivePageUrl = chrome.runtime.getURL('index.html');
    const existingTabs = await chrome.tabs.query({ url: archivePageUrl });
    if (existingTabs.length > 0) {
      await chrome.tabs.update(existingTabs[0].id, { active: true });
      const win = await chrome.windows.get(existingTabs[0].windowId);
      await chrome.windows.update(win.id, { focused: true });
    } else {
      await chrome.tabs.create({ url: archivePageUrl });
    }
    window.close();
  });
});
