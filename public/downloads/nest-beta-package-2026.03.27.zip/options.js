// Options page script - manages AI model settings in chrome.storage.local

const providerSelect = document.getElementById('ai-provider');
const apiKeyInput = document.getElementById('api-key');
const saveBtn = document.getElementById('save-btn');
const statusBanner = document.getElementById('status-banner');
const apiHint = document.getElementById('api-hint');
const customFields = document.getElementById('custom-fields');
const customBaseUrlInput = document.getElementById('custom-base-url');
const customModelInput = document.getElementById('custom-model');

const providerHints = {
  qwen: 'Beta primary. Get your key at <a href="https://openrouter.ai/keys" target="_blank">openrouter.ai/keys</a>. Default model: qwen/qwen3-235b-a22b:free.',
  glm: 'Get your key at <a href="https://bigmodel.cn" target="_blank">bigmodel.cn</a>. GLM-4-Flash can be free, but it still requires a BigModel API Key.',
  openai: 'Get your key at <a href="https://platform.openai.com/api-keys" target="_blank">platform.openai.com/api-keys</a>.',
  xai: 'Get your key at <a href="https://console.x.ai/" target="_blank">console.x.ai</a> for Grok models.',
  groq: 'Get your key at <a href="https://console.groq.com/keys" target="_blank">console.groq.com/keys</a>. Great for fast inference.',
  together: 'Get your key at <a href="https://api.together.xyz/settings/api-keys" target="_blank">api.together.xyz</a>.',
  siliconflow: 'Get your key at <a href="https://cloud.siliconflow.cn" target="_blank">cloud.siliconflow.cn</a>.',
  fireworks: 'Get your key at <a href="https://fireworks.ai" target="_blank">fireworks.ai</a>.',
  deepseek: 'Get your key at <a href="https://platform.deepseek.com/" target="_blank">platform.deepseek.com</a>. Extremely low cost.',
  kimi: 'Get your key at <a href="https://platform.moonshot.cn/" target="_blank">platform.moonshot.cn</a> for long context.',
  minimax: 'Get your key at <a href="https://platform.minimaxi.com/" target="_blank">platform.minimaxi.com</a>.',
  gemini: 'Get your free key at <a href="https://aistudio.google.com/apikey" target="_blank">aistudio.google.com/apikey</a>.',
  openrouter: 'Get your key at <a href="https://openrouter.ai/keys" target="_blank">openrouter.ai/keys</a>. Supports many free models.',
  custom: 'Enter your OpenAI-compatible API credentials for proxies like SiliconFlow or local LLMs.'
};

const providerDefaults = {
  qwen: { baseUrl: 'https://openrouter.ai/api/v1', model: 'qwen/qwen3-235b-a22b:free' },
  openrouter: { baseUrl: 'https://openrouter.ai/api/v1', model: 'google/gemini-2.0-flash-exp:free' },
  openai: { baseUrl: 'https://api.openai.com/v1/chat/completions', model: 'gpt-4.1-mini' },
  xai: { baseUrl: 'https://api.x.ai/v1/chat/completions', model: 'grok-3-mini-beta' },
  groq: { baseUrl: 'https://api.groq.com/openai/v1/chat/completions', model: 'llama-3.3-70b-versatile' },
  together: { baseUrl: 'https://api.together.xyz/v1/chat/completions', model: 'meta-llama/Llama-3.3-70B-Instruct-Turbo' },
  siliconflow: { baseUrl: 'https://api.siliconflow.cn/v1/chat/completions', model: 'Qwen/Qwen2.5-72B-Instruct' },
  fireworks: { baseUrl: 'https://api.fireworks.ai/inference/v1/chat/completions', model: 'accounts/fireworks/models/llama4-maverick-instruct-basic' }
};

const providersWithCustomFields = new Set([
  'qwen',
  'openrouter',
  'openai',
  'xai',
  'groq',
  'together',
  'siliconflow',
  'fireworks',
  'custom'
]);

// Load saved key on open
chrome.storage.local.get(['ai_provider', 'ai_api_key', 'gemini_api_key', 'custom_base_url', 'custom_model'], (result) => {
  // Migration & Defaults
  let provider = result.ai_provider || 'qwen';
  let key = result.ai_api_key || '';

  if (!result.ai_api_key && result.gemini_api_key) {
    provider = 'gemini';
    key = result.gemini_api_key;
  }

  providerSelect.value = provider;
  apiKeyInput.value = key;
  customBaseUrlInput.value = result.custom_base_url || '';
  customModelInput.value = result.custom_model || '';
  updateHint();
});

function updateHint() {
  const provider = providerSelect.value;
  apiHint.innerHTML = providerHints[provider] || providerHints.qwen;
  apiKeyInput.placeholder = `Enter your ${providerSelect.options[providerSelect.selectedIndex].text.split(' ')[0]} API key...`;

  if (providersWithCustomFields.has(provider)) {
    customFields.style.display = 'block';

    const defaults = providerDefaults[provider];
    if (defaults) {
      if (!customBaseUrlInput.value) customBaseUrlInput.value = defaults.baseUrl;
      if (!customModelInput.value) customModelInput.value = defaults.model;
    }
  } else {
    customFields.style.display = 'none';
  }
}

providerSelect.addEventListener('change', updateHint);

function showStatus(message, type) {
  statusBanner.textContent = message;
  statusBanner.className = `status-banner ${type}`;
  setTimeout(() => {
    statusBanner.className = 'status-banner';
  }, 3000);
}

saveBtn.addEventListener('click', () => {
  const provider = providerSelect.value;
  const key = apiKeyInput.value.trim();

  if (!key) {
    showStatus('⚠️  Please enter your API Key.', 'error');
    return;
  }

  if (provider === 'gemini' && !key.startsWith('AIza')) {
    showStatus('⚠️  API key format looks incorrect for Gemini. It should start with "AIza".', 'error');
    return;
  }

  if (provider === 'deepseek' && !key.startsWith('sk-')) {
    showStatus('⚠️  DeepSeek API key usually starts with "sk-".', 'error');
    // We let it pass but it's a warning if we wanted it hard blocked. For now, let's keep it soft or trust the user.
  }

  if (provider === 'glm' && key.length < 16) {
    showStatus('⚠️  GLM 免费模型也需要 BigModel API Key。请确认这里填的是 bigmodel.cn 的 Key。', 'error');
    return;
  }

  const customBaseUrl = customBaseUrlInput.value.trim();
  const customModel = customModelInput.value.trim();

  if (provider === 'custom') {
    if (!customBaseUrl || !customModel) {
      showStatus('⚠️  Base URL and Model Name are required for custom providers.', 'error');
      return;
    }
  }

  chrome.storage.local.set({
    ai_provider: provider,
    ai_api_key: key,
    custom_base_url: customBaseUrl,
    custom_model: customModel
  }, () => {
    if (chrome.runtime.lastError) {
      showStatus('❌ Failed to save. Please try again.', 'error');
    } else {
      showStatus('✓ AI settings saved successfully!', 'success');
    }
  });
});

// Allow Enter key to save
apiKeyInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') saveBtn.click();
});
